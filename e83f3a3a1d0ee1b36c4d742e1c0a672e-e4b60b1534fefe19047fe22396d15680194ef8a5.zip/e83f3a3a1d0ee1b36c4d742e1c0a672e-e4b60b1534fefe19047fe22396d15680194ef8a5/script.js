function mudaModo() {
  document.body.classList.toggle("dark");
}
